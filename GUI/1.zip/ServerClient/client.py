from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QVBoxLayout, QLineEdit 
from PySide6.QtCore import Signal, QObject, Qt

from PySide6.QtGui import QImage, QPixmap, QKeyEvent, QIcon
import cv2
import numpy as np
import socket
import struct
import sys
import threading

class Communicate(QObject):
    update_frame_signal = Signal()  # Сигнал для обновления кадра

class ScreenShareClient(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowIcon(QIcon('Font/cs.ico'))
        self.setWindowTitle("Counter-Strike 2")        
        self.setGeometry(100, 100, 800, 600)
        self.setMinimumSize(640, 480)  # Минимальный размер окна

        # Поле для IP
        self.label_ip = QLabel("Введите IP сервера:")
        self.ip_input = QLineEdit()

        # Кнопка подключения
        self.connect_button = QPushButton("Подключиться")
        self.disconnect_button = QPushButton("Отключиться")

        # Поле для статуса
        self.status_label = QLabel("Отключено")
        self.update_status("Отключено", "red")

        self.connect_button.clicked.connect(self.start_streaming)
        self.disconnect_button.clicked.connect(self.stop_streaming)

        # Виджет для отображения видео
        self.video_label = QLabel(self)

        # Размещение элементов
        layout = QVBoxLayout()
        layout.addWidget(self.label_ip)
        layout.addWidget(self.ip_input)
        layout.addWidget(self.connect_button)
        layout.addWidget(self.disconnect_button)
        layout.addWidget(self.status_label)
        layout.addWidget(self.video_label)

        self.setLayout(layout)

        self.client_socket = None
        self.running = False
        self.is_connected = False

        self.current_frame = None  # Храним текущий кадр для отображения

        # Создаем объект для сигналов
        self.comm = Communicate()
        self.comm.update_frame_signal.connect(self.update_frame)

    def update_status(self, text, color):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(f"color: {color}; font-weight: bold;")

    def start_streaming(self):
        self.update_status("Идёт подключение...", "yellow")
        self.running = True
        threading.Thread(target=self.receive_stream, daemon=True).start()

    def stop_streaming(self):
        self.running = False
        if self.client_socket:
            self.client_socket.close()
        self.update_status("Отключено", "red")

    def receive_stream(self):
        server_ip = self.ip_input.text()
        PORT = 5000

        try:
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_socket.connect((server_ip, PORT))
            self.is_connected = True
            self.update_status("Подключено", "green")

            # Скрываем элементы управления
            self.label_ip.setVisible(False)
            self.ip_input.setVisible(False)
            self.connect_button.setVisible(False)
            self.disconnect_button.setVisible(False)
            self.status_label.setVisible(False)

            while self.running:

                data_size = struct.unpack("!I", self.client_socket.recv(4))[0]


                data = b''
                while len(data) < data_size:
                    packet = self.client_socket.recv(data_size - len(data))
                    if not packet:
                        break
                    data += packet


                self.current_frame = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)


                self.comm.update_frame_signal.emit()

        except Exception as e:
            self.update_status(f"Ошибка: {e}", "red")
            self.stop_streaming()

    def update_frame(self):
        if self.current_frame is not None:

            width = self.width()
            height = self.height()

   
            frame_resized = cv2.resize(self.current_frame, (width, height))
            height, width, channel = frame_resized.shape
            bytes_per_line = channel * width
            q_img = QImage(frame_resized.data, width, height, bytes_per_line, QImage.Format_BGR888)


            self.video_label.setPixmap(QPixmap.fromImage(q_img))

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_F11:
            if self.isFullScreen():
                self.setWindowState(Qt.WindowNoState)  # Выход из полноэкранного режима
            else:
                self.setWindowState(Qt.WindowFullScreen)  # Вход в полноэкранный режим

if __name__ == "__main__":
    app = QApplication(sys.argv)
    client = ScreenShareClient()
    client.show()
    sys.exit(app.exec())
